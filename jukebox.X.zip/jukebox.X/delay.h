#ifndef DELAY_H
#define	DELAY_H

void tempo(unsigned int num_ms);

#endif	/* DELAY_H */

